import base64
import json
import os
import time
from typing import Any, Dict, List, Optional

import requests
from flask import Flask, request, jsonify
from flask_cors import CORS

try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": "*"}})

# ==============================
# DeepSeek 配置：只放在后端，不要写到前端
# ==============================
DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY", "").strip()
DEEPSEEK_API_BASE = os.getenv("DEEPSEEK_API_BASE", "https://api.deepseek.com").rstrip("/")
DEEPSEEK_MODEL = os.getenv("DEEPSEEK_MODEL", "deepseek-v4-flash").strip() or "deepseek-v4-flash"
REQUEST_TIMEOUT = int(os.getenv("DEEPSEEK_TIMEOUT", "45"))

# ==============================
# 百度短语音识别配置：只放在后端，不要写到前端
# ==============================
BAIDU_ASR_APP_ID = os.getenv("BAIDU_ASR_APP_ID", "").strip()
BAIDU_ASR_API_KEY = os.getenv("BAIDU_ASR_API_KEY", "").strip()
BAIDU_ASR_SECRET_KEY = os.getenv("BAIDU_ASR_SECRET_KEY", "").strip()
BAIDU_ASR_DEV_PID = int(os.getenv("BAIDU_ASR_DEV_PID", "1537"))  # 1537=普通话，近场识别，带标点
BAIDU_ASR_CUID = os.getenv("BAIDU_ASR_CUID", "cooking-agent-local").strip()[:60] or "cooking-agent-local"
BAIDU_TOKEN_URL = "https://aip.baidubce.com/oauth/2.0/token"
BAIDU_ASR_URL = "http://vop.baidu.com/server_api"
BAIDU_TIMEOUT = int(os.getenv("BAIDU_ASR_TIMEOUT", "20"))

_baidu_token_cache: Dict[str, Any] = {"access_token": "", "expires_at": 0}


def _deepseek_chat(messages: List[Dict[str, str]], temperature: float = 0.65, max_tokens: int = 900) -> str:
    """Call DeepSeek Chat Completions API. The API key stays only on the backend."""
    if not DEEPSEEK_API_KEY:
        raise RuntimeError(
            "后端没有配置 DEEPSEEK_API_KEY。请在 后端/.env 中填写 DEEPSEEK_API_KEY=你的key，或设置系统环境变量。"
        )

    url = f"{DEEPSEEK_API_BASE}/chat/completions"
    headers = {
        "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": DEEPSEEK_MODEL,
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
        "stream": False,
    }

    response = requests.post(url, headers=headers, json=payload, timeout=REQUEST_TIMEOUT)
    if response.status_code >= 400:
        raise RuntimeError(f"DeepSeek API 请求失败：HTTP {response.status_code}，{response.text}")

    data = response.json()
    choices = data.get("choices") or []
    if not choices:
        raise RuntimeError(f"DeepSeek API 未返回 choices：{data}")

    message = choices[0].get("message") or {}
    reply = (message.get("content") or choices[0].get("text") or "").strip()
    if not reply:
        raise RuntimeError(f"DeepSeek API 返回内容为空：{data}")
    return reply


def _safe_history(raw_history: Any, max_items: int = 12) -> List[Dict[str, str]]:
    if not isinstance(raw_history, list):
        return []
    cleaned: List[Dict[str, str]] = []
    for item in raw_history[-max_items:]:
        if not isinstance(item, dict):
            continue
        role = item.get("role")
        content = str(item.get("content", "")).strip()
        if role in {"user", "assistant"} and content:
            cleaned.append({"role": role, "content": content[:1200]})
    return cleaned


def _recipe_context_to_text(recipe_context: Dict[str, Any]) -> str:
    if not isinstance(recipe_context, dict):
        return "用户当前在做饭页面，但没有传入具体菜谱。"
    title = str(recipe_context.get("title") or "当前菜谱").strip()
    meta = str(recipe_context.get("meta") or "").strip()
    ingredients = recipe_context.get("ingredients") or []
    if isinstance(ingredients, list):
        ingredients_text = "、".join([str(x).strip() for x in ingredients if str(x).strip()])
    else:
        ingredients_text = str(ingredients)
    page = str(recipe_context.get("page") or "").strip()
    return f"菜谱：{title}\n页面信息：{meta}\n已有食材：{ingredients_text or '页面未列出'}\n来源页面：{page or '未知'}"


def _build_cooking_messages(user_message: str, recipe_context: Dict[str, Any], history: List[Dict[str, str]]) -> List[Dict[str, str]]:
    recipe_text = _recipe_context_to_text(recipe_context)
    system_prompt = f"""
你是“糯糯”，一个小浣熊形象的中文做饭语音智能体，正在通过类似豆包语音通话的页面陪用户做饭。
你的任务：像真人厨友一样，一步一步指导用户完成当前菜谱，并持续给情绪价值。

当前菜谱上下文：
{recipe_text}

回复规则：
1. 面向语音播报，回复要自然、温暖、有陪伴感，先肯定用户，再给下一步。
2. 一次只讲一个明确步骤，不要一次性把完整菜谱全部讲完。
3. 每次回复尽量控制在 30 到 120 个汉字，适合 TTS 朗读。
4. 用户说“好了 / 做好了 / 下一步 / 继续”时，推进到下一步；用户卡住时，先安抚再解释。
5. 涉及刀具、热油、明火、烤箱、过敏原、食材变质时，要简短提醒安全。
6. 不要编造自己能看见用户画面；如果需要确认状态，就直接问用户。
7. 不输出 Markdown 表格，不使用复杂编号。可以用短句和少量标点。
""".strip()

    messages = [{"role": "system", "content": system_prompt}]
    messages.extend(history)
    messages.append({"role": "user", "content": user_message[:1200]})
    return messages


def _get_baidu_access_token() -> str:
    """Get and cache Baidu OAuth access_token. Audio is not saved anywhere."""
    if not BAIDU_ASR_API_KEY or not BAIDU_ASR_SECRET_KEY:
        raise RuntimeError("后端没有配置百度 ASR：请在 .env 中填写 BAIDU_ASR_API_KEY 和 BAIDU_ASR_SECRET_KEY。")

    now = int(time.time())
    cached = _baidu_token_cache.get("access_token")
    if cached and int(_baidu_token_cache.get("expires_at", 0)) > now + 300:
        return str(cached)

    params = {
        "grant_type": "client_credentials",
        "client_id": BAIDU_ASR_API_KEY,
        "client_secret": BAIDU_ASR_SECRET_KEY,
    }
    response = requests.post(BAIDU_TOKEN_URL, params=params, timeout=BAIDU_TIMEOUT)
    if response.status_code >= 400:
        raise RuntimeError(f"百度 access_token 获取失败：HTTP {response.status_code}，{response.text}")

    data = response.json()
    token = data.get("access_token")
    if not token:
        raise RuntimeError(f"百度 access_token 返回为空：{data}")

    expires_in = int(data.get("expires_in", 2592000))
    _baidu_token_cache["access_token"] = token
    _baidu_token_cache["expires_at"] = now + expires_in - 600
    return str(token)


def _baidu_asr_from_wav_bytes(wav_bytes: bytes) -> Dict[str, Any]:
    """
    Send 16k/16bit/mono WAV bytes to Baidu short speech ASR.
    The bytes are received from frontend memory Blob and never written to disk.
    """
    if not wav_bytes:
        raise RuntimeError("没有收到音频数据。")
    if len(wav_bytes) < 1200:
        raise RuntimeError("收到的音频太短，请说完整一句话。")
    if len(wav_bytes) > 10 * 1024 * 1024:
        raise RuntimeError("单次语音过长，请每次说一句短句。")

    token = _get_baidu_access_token()
    payload = {
        "format": "wav",
        "rate": 16000,
        "channel": 1,
        "cuid": BAIDU_ASR_CUID,
        "token": token,
        "dev_pid": BAIDU_ASR_DEV_PID,
        "speech": base64.b64encode(wav_bytes).decode("utf-8"),
        "len": len(wav_bytes),
    }
    response = requests.post(
        BAIDU_ASR_URL,
        headers={"Content-Type": "application/json"},
        json=payload,
        timeout=BAIDU_TIMEOUT,
    )
    if response.status_code >= 400:
        raise RuntimeError(f"百度 ASR 请求失败：HTTP {response.status_code}，{response.text}")

    data = response.json()
    err_no = int(data.get("err_no", -1))
    if err_no != 0:
        err_msg = data.get("err_msg", "unknown error")
        sn = data.get("sn", "")
        friendly = {
            2000: "音频数据为空或格式不对。",
            3300: "参数错误，请检查 wav/16000/单声道 配置。",
            3301: "音频质量过差或没有清晰人声，请靠近麦克风再说。",
            3302: "鉴权失败，请检查百度 API Key / Secret Key。",
            3303: "百度服务端识别异常，请稍后重试。",
            3304: "请求并发或次数受限，请稍后重试。",
            3305: "免费额度或 QPS 可能受限，请检查百度控制台。",
        }.get(err_no, "百度 ASR 没有识别成功。")
        raise RuntimeError(f"{friendly} 百度返回：err_no={err_no}, err_msg={err_msg}, sn={sn}")

    result = data.get("result") or []
    text = str(result[0]).strip() if result else ""
    if not text:
        raise RuntimeError(f"百度 ASR 识别结果为空：{data}")
    return {"text": text, "raw": data}


@app.route("/api/chat", methods=["POST"])
def chat():
    """Generic recipe recommendation endpoint, now also backed by DeepSeek."""
    data = request.get_json(silent=True) or {}
    user_message = str(data.get("message", "")).strip()
    if not user_message:
        return jsonify({"error": "No message provided"}), 400

    messages = [
        {
            "role": "system",
            "content": (
                "你是一个中文美食营养专家。根据用户的饮食目标、口味和需求，生成个性化食谱建议。"
                "输出包含菜品名称、口味描述、主要食材、制作步骤和热量提示。语言要简洁友好。"
            ),
        },
        {"role": "user", "content": f"请根据以下饮食需求生成个性化食谱：{user_message}"},
    ]

    try:
        reply = _deepseek_chat(messages, temperature=0.75, max_tokens=900)
        return jsonify({"reply": reply, "model": DEEPSEEK_MODEL})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@app.route("/api/cooking-agent", methods=["POST"])
def cooking_agent():
    """Text fallback endpoint. The voice endpoint below uses Baidu ASR first, then calls the same DeepSeek prompt."""
    data = request.get_json(silent=True) or {}
    user_message = str(data.get("message", "")).strip()
    if not user_message:
        return jsonify({"error": "没有收到用户文字。"}), 400

    recipe_context = data.get("recipe_context") or {}
    history = _safe_history(data.get("history"), max_items=14)

    try:
        messages = _build_cooking_messages(user_message, recipe_context, history)
        reply = _deepseek_chat(messages, temperature=0.7, max_tokens=450)
        return jsonify({"reply": reply, "model": DEEPSEEK_MODEL, "ts": int(time.time())})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@app.route("/api/cooking-voice", methods=["POST"])
def cooking_voice():
    """
    Frontend microphone -> in-memory WAV Blob -> this endpoint -> Baidu ASR -> DeepSeek -> text reply.
    No audio file is created or saved by this backend.
    """
    audio = request.files.get("audio")
    if audio is None:
        return jsonify({"error": "没有收到 audio 字段。前端需要用 FormData 上传内存里的 wav Blob。"}), 400

    try:
        wav_bytes = audio.read()
        asr = _baidu_asr_from_wav_bytes(wav_bytes)
        user_text = asr["text"]

        try:
            history_raw = json.loads(request.form.get("history", "[]"))
        except Exception:
            history_raw = []
        try:
            recipe_context = json.loads(request.form.get("recipe_context", "{}"))
        except Exception:
            recipe_context = {}

        history = _safe_history(history_raw, max_items=14)
        messages = _build_cooking_messages(user_text, recipe_context, history)
        reply = _deepseek_chat(messages, temperature=0.7, max_tokens=450)
        return jsonify(
            {
                "asr_text": user_text,
                "reply": reply,
                "model": DEEPSEEK_MODEL,
                "asr_engine": "baidu_short_speech",
                "ts": int(time.time()),
            }
        )
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@app.route("/api/ping", methods=["GET"])
def ping():
    return jsonify(
        {
            "status": "ok",
            "message": "DeepSeek + Baidu ASR 后端运行中",
            "model": DEEPSEEK_MODEL,
            "has_deepseek_key": bool(DEEPSEEK_API_KEY),
            "has_baidu_asr_key": bool(BAIDU_ASR_API_KEY and BAIDU_ASR_SECRET_KEY),
            "baidu_dev_pid": BAIDU_ASR_DEV_PID,
            "audio_saved": False,
        }
    )


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
