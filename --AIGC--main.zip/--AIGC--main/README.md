# 做饭语音智能体启动说明

这版已经改成：

前端麦克风采集语音 → 前端生成内存 WAV Blob → POST 到 Flask 后端 → 百度短语音识别 ASR 转文字 → 文字发给 DeepSeek → DeepSeek 回复文字 → 浏览器 TTS 语音播报。

后端不会把音频保存成文件，只在接口请求内存中读取一次音频字节，识别完成后丢弃。

## 1. 目录说明

压缩包解压后会看到：

```text
--AIGC--main
├─ #U524d#U7aef    前端目录
├─ #U540e#U7aef    后端目录
└─ README.md
```

如果 Windows 显示成 `#U524d#U7aef` 和 `#U540e#U7aef`，可以手动重命名：

```text
#U524d#U7aef  → frontend
#U540e#U7aef  → backend
```

## 2. 配置后端 Key

进入后端目录：

```powershell
cd backend
```

如果没有重命名：

```powershell
cd "#U540e#U7aef"
```

复制环境变量模板：

```powershell
Copy-Item .env.example .env
```

打开配置文件：

```powershell
notepad .env
```

填入你的 DeepSeek Key 和百度智能云语音识别应用信息：

```env
DEEPSEEK_API_KEY=sk-你的DeepSeekKey
DEEPSEEK_API_BASE=https://api.deepseek.com
DEEPSEEK_MODEL=deepseek-v4-flash

BAIDU_ASR_APP_ID=你的百度AppID
BAIDU_ASR_API_KEY=你的百度APIKey
BAIDU_ASR_SECRET_KEY=你的百度SecretKey
BAIDU_ASR_DEV_PID=1537
BAIDU_ASR_CUID=cooking-agent-local
```

注意：不要把这些 Key 写进前端 HTML，也不要上传到公开仓库。

## 3. 启动后端

安装依赖：

```powershell
pip install -r requirements.txt
```

启动后端：

```powershell
python app.py
```

浏览器打开检查：

```text
http://127.0.0.1:5000/api/ping
```

正常应看到类似：

```json
{
  "status": "ok",
  "has_deepseek_key": true,
  "has_baidu_asr_key": true,
  "audio_saved": false
}
```

如果 `has_baidu_asr_key` 是 `false`，说明 `.env` 中百度 Key 没填好。

## 4. 启动前端

另开一个终端，进入前端目录：

```powershell
cd frontend
```

如果没有重命名：

```powershell
cd "#U524d#U7aef"
```

启动本地网页服务：

```powershell
python -m http.server 8080
```

浏览器打开：

```text
http://127.0.0.1:8080/food_app_video_call.html
```

不要直接双击 HTML 文件，直接双击会走 `file://`，麦克风权限容易失败。

## 5. 使用方法

1. 打开页面。
2. 点击“开始通话”。
3. 浏览器弹出麦克风权限时点“允许”。
4. 等糯糯欢迎语说完。
5. 你直接说一句话，例如：“开始吧”“我切好了”“下一步”。
6. 页面会显示 RMS/峰值，检测到你说完一句话后自动上传内存 Blob 识别。
7. 百度 ASR 识别成文字，DeepSeek 回复，糯糯用 TTS 播放。

## 6. 常见问题

### 识别不到声音

检查页面底部的 RMS/峰值：

- RMS 长期是 0.0000：浏览器没有拿到麦克风音频，检查系统默认输入设备、浏览器麦克风权限、物理静音键。
- RMS 有变化，但不上传：声音太小，靠近麦克风或提高系统输入音量。
- 上传后报 3301：百度认为音频质量差或没有清晰人声，靠近麦克风再说完整一句。

### 后端连接失败

确认后端终端仍在运行，并且访问下面地址正常：

```text
http://127.0.0.1:5000/api/ping
```

### 百度鉴权失败

检查 `.env` 中：

```env
BAIDU_ASR_API_KEY=...
BAIDU_ASR_SECRET_KEY=...
```

不要把 AppID 填到 API Key 里，也不要把 API Key 填到 Secret Key 里。
